document.addEventListener("DOMContentLoaded", () => {
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");
    const submitBtn = document.getElementById("submit-btn");
    const questions = document.querySelectorAll(".question");
    let currentQuestion = 0;

    function showQuestion(index) {
        questions[currentQuestion].style.display = "none";
        currentQuestion = index;
        questions[currentQuestion].style.display = "block";

        prevBtn.disabled = currentQuestion === 0;
        nextBtn.style.display = currentQuestion === questions.length - 1 ? "none" : "inline-block";
        submitBtn.style.display = currentQuestion === questions.length - 1 ? "inline-block" : "none";
    }

    prevBtn.addEventListener("click", () => showQuestion(currentQuestion - 1));
    nextBtn.addEventListener("click", () => showQuestion(currentQuestion + 1));
});