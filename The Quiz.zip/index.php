<?php
require_once 'config.php';
isLoggedIn();
?>


<?php include_once "header.php" ?>
<title>Home-The Quiz</title>
   

      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
       
      <!-- Nav -->
      <header>
         <!-- nav inner -->
         <div class="header bg-dark">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo"> <a href="index.php"><img src="images/fabi.png" alt="#"></a> </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <div class="menu-area">
                        <div class="limit-box">
                           <nav class="main-menu">
                              <ul class="menu-area-main">
                                 <li class="active"> <a href="index.php">Home</a> </li>
                                 <li> <a href="about.php">About us</a> </li>
                                 <li><a href="logout.php">Logout</a></li>
                                 <li class="mean-last"> <a href="#"><img src="images/top-icon.png" alt="#" /></a> </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
         <!-- nav inner -->
      </header>
      <!-- end nav -->

      <div class="about-bg">
         <div class="container">
            <div class="row">
               <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                  <div class="abouttitle">
                     <h2><i>The Quiz</i></h2>
                  </div>
               </div>
            </div>
         </div>
      </div>



      <!--quiz -->
      <div class="Books mt-3">
         <div class="container">
            <div class="row">
               <div class="col-md-10 offset-md-1">
                  <div class="titlepage">
                     <h2  class="black">Wellcome to Our <strong>Quiz</strong></h2>
                     <span>Hello, User! Are you ready to test your knowledge?</span> 
                  </div>
               </div>
            </div>
            <div class="row box mb-4">
              
               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                  <div class="book-box">
                     <figure><img src="images/img1.jpeg" alt="img"/></figure>
                  </div>
               </div>
               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
               <div class="read-more">
                        <a href="quiz.php">Start Quiz</a>
                     </div>
               </div>
               
            </div>
            
         </div>
      </div>
      <!-- end quiz -->


<?php require_once 'footer.php'; ?>
