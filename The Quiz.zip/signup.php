<?php
require_once 'config.php';
isLoggedout();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = new User($conn);

    // Check if the email already exists
    if ($user->emailExists($_POST['email'])) {
        $error = "This email is already registered. Please log in or use a different email.";
    } else {
        // Proceed with registration
        $success = $user->register(
            $_POST['firstname'],
            $_POST['lastname'],
            $_POST['dob'],
            $_POST['mobile'],
            $_POST['email'],
            $_POST['password']
        );

        if ($success) {
            $abc= "Sign Up Done. Please Sign In .";
            echo "<p class='alert alert-success'>$abc</p>";
        } else {
            $error = "Signup failed. Please try again.";
        }
    }
}
?>

<!-- HTML Signup Form -->
<?php require_once 'header.php'; ?>

<title>Signup-The Quiz</title>
    
    
<section class="bg-primary py-3 py-md-5 py-xl-8">
  <div class="container">
    <div class="row gy-4 align-items-center">
        <div class="d-flex justify-content-center text-bg-primary">
          <div class="col-12 col-xl-12">
            <img class="img-fluid rounded mb-4" loading="lazy" src="images/logo.png" width="245" height="80" alt="BootstrapBrain Logo">
            
          </div>
        </div>
    </div>
    <div class="row gy-4 align-items-center">
      <div class="col-12 col-md-12 col-xl-12">
        <div class="card border-0 rounded-4">
        <?php if (isset($error)) echo "<p class='alert alert-danger'>$error</p>"; ?>

          <div class="card-body p-3 p-md-4 p-xl-5">
            <div class="row">
              <div class="col-12">
                <div class="mb-4">
                  <h3>Sign Up</h3>
                  <p>Already have an account? <a href="login.php">Sign in</a></p>
                </div>
              </div>
            </div>

            <form action="" method="POST">
              <div class="row gy-3 overflow-hidden">
                <div class="col-6">
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="firstname" id="firstname" required>
                    <label for="firstame" class="form-label">First Name</label>
                  </div>
                </div>

                <div class="col-6">
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="lastname" id="lastname" required>
                    <label for="lastname" class="form-label">Last Name</label>
                  </div>
                </div>
                <div class="col-6">
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="mobile" required>
                    <label for="mobile" class="form-label">Mobile No.</label>
                  </div>
                </div>
                <div class="col-6">
                  <div class="form-floating mb-3">
                    <input type="date" class="form-control" name="dob" required>
                    <label for="dob" class="form-label">Date of Birth</label>
                  </div>
                </div>
                <div class="col-6">
                  <div class="form-floating mb-3">
                    <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
                    <label for="email" class="form-label">Email</label>
                  </div>
                </div>
                <div class="col-6">
                  <div class="form-floating mb-3">
                    <input type="password" class="form-control" name="password" id="password" value="" placeholder="Password" required>
                    <label for="password" class="form-label">Password</label>
                  </div>
                </div>

                <div class="col-12">
                  <div class="d-grid">
                    <button class="btn btn-primary btn-lg" type="submit">Sign Up</button>
                  </div>
                </div>


              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php require_once 'footer.php'; ?>