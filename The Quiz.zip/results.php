<?php
require_once 'config.php';
isLoggedIn();

if (!isset($_SESSION['responses'])) {
    header("Location: quiz.php");
    exit();
}

$quiz = new Quiz($conn);
$responses = $_SESSION['responses'];
$score = $quiz->calculateScore($responses);
?>

<!-- HTML Results Page -->
<?php require_once "header.php" ; ?>

<title>Result-The Quiz</title>

<header>
         <!-- nav inner -->
         <div class="header bg-dark">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo"> <a href="index.php"><img src="images/fabi.png" alt="#"></a> </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <div class="menu-area">
                        <div class="limit-box">
                           <nav class="main-menu">
                              <ul class="menu-area-main">
                                 <li > <a href="index.php">Home</a> </li>
                                <li class="nav-item dropdown">
                                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                     <img src="images/top-icon.png">
                                     </a>
                                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="logout.php">Logout</a>
                                  </div>
                                </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
         <!-- nav inner -->
      </header>


     <div class="Library">
         <div class="container">
            <div class="row">
               <div class="col-10 offset-md-1">
                  <div class="titlepage">
                     <h2><strong>Your Result</strong></h2>
                  </div>
               </div>
            </div>
         </div>

         <div class="container">
            <div class="row">
               <div class="col-md-12">
    <p class="alert alert-primary">Your Score: <?php echo $score; ?>/10</p>
    <ul>
        <?php foreach ($responses as $id => $answer) {
            $stmt = $conn->prepare("SELECT question, correct_option, option1, option2, option3, option4 FROM questions WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $question = $stmt->get_result()->fetch_assoc();

            echo "<li class='alert alert-light'>" . htmlspecialchars($question['question']) . "<br>";
            echo "Your Answer: " . htmlspecialchars($question["option$answer"]) . "<br>";
            echo "Correct Answer: " . htmlspecialchars($question["option" . $question['correct_option']]) . "</li><br>";
        } ?>
    </ul>

    
    </div>
            </div>
         </div>
      </div>




    <?php require_once "footer.php" ; ?>
