<?php
session_start();

require_once 'classes/Database.php';
require_once 'classes/User.php';
require_once 'classes/Quiz.php';

// Database connection
$db = new Database();
$conn = $db->connect();

// Redirect if not logged in
function isLoggedIn() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
}

// Redirect if not logged out
function isLoggedout() {
    if (isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}
?>