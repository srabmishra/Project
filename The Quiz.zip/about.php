<?php
require_once 'config.php';
isLoggedIn();
?>


<?php include_once "header.php" ?>
<title>About-The Quiz</title>
   

      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
       
      <!-- Nav -->
      <header>
         <!-- nav inner -->
         <div class="header bg-dark">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo"> <a href="index.php"><img src="images/fabi.png" alt="#"></a> </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <div class="menu-area">
                        <div class="limit-box">
                           <nav class="main-menu">
                              <ul class="menu-area-main">
                                 <li> <a href="index.php">Home</a> </li>
                                 <li class="active"> <a href="about.php">About us</a> </li>
                                 <li><a href="logout.php">Logout</a></li>
                                 <li class="mean-last"> <a href="#"><img src="images/top-icon.png" alt="#" /></a> </li>

                              </ul>
                           </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
         <!-- nav inner -->
      </header>
      <!--End Nav -->

            <!-- about -->
            <div class="about-bg">
         <div class="container">
            <div class="row">
               <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                  <div class="abouttitle">
                     <h2>About Us</h2>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="about">
         <div class="container">
            <div class="row">
               <div class="col-md-10 offset-md-1">
                  <div class="aboutheading">
                     <span>"Test your knowledge with fun, challenging questions! Answer quickly and accurately to earn points and rise to victory!"</span>
                  </div>
               </div>
            </div>
            <div class="row border">
               <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12">
                  <div class="about-box">
                     <p>"Welcome to the ultimate quiz challenge! Test your knowledge across various categories, from general trivia to specialized topics. Each question is designed to challenge your intellect and keep you on your toes. Answer as quickly and accurately as possible to earn points and climb up the leaderboard. With multiple levels of difficulty, every round gets more exciting and intense. Compete against friends or players around the world and see who comes out on top. Sharpen your mind, learn new facts, and enjoy endless fun. Ready to become the quiz champion? Start playing now and test your skills!"</p>
                     <a href="#">Read More</a>
                  </div>
               </div>
               <div class="col-xl-5 col-lg-5 col-md-12 col-sm-12">
                  <div class="about-box">
                     <figure><img src="images/about.png" alt="img" /></figure>
                  </div>
               </div>
            </div>
         </div>
      </div>
      </div>
      <!-- end about -->





<?php require_once 'footer.php'; ?>
