<?php
require_once 'config.php';
isLoggedIn();

$quiz = new Quiz($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['responses'])) {
    $_SESSION['responses'] = $_POST['responses'];
    header("Location: results.php");
    exit();
}

$questions = $quiz->getRandomQuestions();
?>

<!-- HTML Quiz Page -->

<?php require_once 'header.php'; ?>

<title>Quiz-The Quiz</title>


<header>
         <!-- nav inner -->
         <div class="header bg-dark">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                           <div class="logo"> <a href="index.php"><img src="images/fabi.png" alt="#"></a> </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                     <div class="menu-area">
                        <div class="limit-box">
                           <nav class="main-menu">
                              <ul class="menu-area-main">
                                 <li > <a href="index.php">click for Quit</a> </li>
                                <li class="nav-item dropdown">
                                     <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                     <img src="images/top-icon.png">
                                     </a>
                                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="logout.php">Logout</a>
                                  </div>
                                </li>
                              </ul>
                           </nav>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         </div>
         <!-- nav inner -->
      </header>


<form method="POST" id="quiz-form">
     <div class="Library">
         <div class="container">
            <div class="row">
               <div class="col-10 offset-md-1">
                  <div class="titlepage">
                     <h2><strong class="black">The </strong><strong>Quiz</strong></h2>
                  </div>
               </div>
            </div>
         </div>

         <div class="container">
            <div class="row">
               <div class="col-md-12">

               <div id="question-container">
            <?php $i = 1; while ($question = $questions->fetch_assoc()) { ?>
                <div class="question" data-id="<?php echo $i; ?>" <?php if ($i > 1) echo 'style="display:none;"'; ?>>
                    <p class="alert alert-primary"><?php echo $i . ". " . htmlspecialchars($question['question']); ?></p>
                    <?php for ($j = 1; $j <= 4; $j++) { ?>
                        <label>
                            <input type="radio" name="responses[<?php echo $question['id']; ?>]" value="<?php echo $j; ?>">
                            <?php echo htmlspecialchars($question["option$j"]); ?>
                        </label><br>
                    <?php } ?>
                </div>
            <?php $i++; } ?>
        </div>
        <button type="button" class="btn btn-primary" id="prev-btn" disabled>Previous</button>
        <button type="button" class="btn btn-primary" id="next-btn">Next</button>
        <button type="submit" class="btn btn-primary" id="submit-btn" style="display:none;">Submit</button>
                  
               </div>
            </div>
         </div>
      </div>


       
    </form>


<?php require_once 'footer.php'; ?>