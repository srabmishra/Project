<?php
class User {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function register($firstname, $lastname, $dob, $mobile, $email, $password) {
        $sanitized_email = $this->sanitize($email);
        $hashed_password = md5($password);
        $stmt = $this->conn->prepare("INSERT INTO users (firstname, lastname, dob, mobile, email, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $firstname, $lastname, $dob, $mobile, $sanitized_email, $hashed_password);
        return $stmt->execute();
    }

    public function login($email, $password) {
        $hashed_password = md5($password);
        $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ? AND password = ?");
        $stmt->bind_param("ss", $email, $hashed_password);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            return $result->fetch_assoc()['id'];
        }
        return false;
    }

    public function resetPassword($email, $fullname, $dob, $new_password) {
        $sanitized_email = $this->sanitize($email);
        $hashed_password = md5($new_password);
        $stmt = $this->conn->prepare("UPDATE users SET password = ? WHERE email = ? AND CONCAT(firstname, ' ', lastname) = ? AND dob = ?");
        $stmt->bind_param("ssss", $hashed_password, $sanitized_email, $fullname, $dob);
        return $stmt->execute();
    }

    private function sanitize($data) {
        return htmlspecialchars(strip_tags($data));
    }

    public function emailExists($email) {
        $sanitized_email = $this->sanitize($email);
        $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $sanitized_email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0; // Returns true if email exists
    }
}
?>