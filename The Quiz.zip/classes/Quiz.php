<?php
class Quiz {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function getRandomQuestions($limit = 10) {
        $query = "SELECT id, question, option1, option2, option3, option4, correct_option FROM questions ORDER BY RAND() LIMIT ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function calculateScore($responses) {
        $score = 0;
        foreach ($responses as $id => $answer) {
            $stmt = $this->conn->prepare("SELECT correct_option FROM questions WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result['correct_option'] == $answer) {
                $score++;
            }
        }
        return $score;
    }
}
?>