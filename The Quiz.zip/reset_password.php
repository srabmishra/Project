<?php
require_once 'config.php';

isLoggedout();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = new User($conn);
    $success = $user->resetPassword(
        $_POST['email'],
        $_POST['fullname'],
        $_POST['dob'],
        $_POST['new_password']
    );
    if ($success) {
        $abc= "If You Have Filled Your all Details Correctly, Your Password Has been Reset";
        echo "<p class='alert alert-warning'>$abc</p>";
    } else {
        $error = "Invalid details. Please try again.";
    }
}
?>

<!-- HTML Reset Password Form -->
<?php require_once 'header.php'; ?>

<title>Forget Password-The Quiz</title>

<section class="bg-primary py-3 py-md-5 py-xl-8">
  <div class="container">
    <div class="row gy-4 align-items-center">
        <div class="d-flex justify-content-center text-bg-primary">
          <div class="col-12 col-xl-12">
            <img class="img-fluid rounded mb-4" loading="lazy" src="images/logo.png" width="245" height="80" alt="BootstrapBrain Logo">
            
          </div>
        </div>
    </div>
    <div class="row gy-4 align-items-center">
      <div class="col-12 col-md-12 col-xl-12">
        <div class="card border-0 rounded-4">
        <?php if (isset($error)) echo "<p class='alert alert-danger'>$error</p>"; ?>

          <div class="card-body p-3 p-md-4 p-xl-5">
            <div class="row">
              <div class="col-12">
                <div class="mb-4">
                  <h3>Reset Password</h3>
                  <p>Already have an account? <a href="login.php">Sign in</a></p>
                  <p>Don't have an account? <a href="signup.php">Sign Un</a></p>
                </div>
              </div>
            </div>

            <form action="" method="POST">
              <div class="row gy-3 overflow-hidden">

               <div class="col-12">
                  <div class="form-floating mb-3">
                    <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
                    <label for="email" class="form-label">Email</label>
                  </div>
                </div>

                <div class="col-12">
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" name="fullname" id="fullname" required>
                    <label for="fullname" class="form-label">Full Name</label>
                  </div>
                </div>

                <div class="col-12">
                  <div class="form-floating mb-3">
                    <input type="date" class="form-control" name="dob" required>
                    <label for="dob" class="form-label">Date of Birth</label>
                  </div>
                </div>
                
                <div class="col-12">
                  <div class="form-floating mb-3">
                    <input type="password" class="form-control" name="new_password" id="new_password" value="" placeholder="New Password" required>
                    <label for="new_password" class="form-label">New Password</label>
                  </div>
                </div>

                <div class="col-12">
                  <div class="d-grid">
                    <button class="btn btn-primary btn-lg" type="submit">Reset</button>
                  </div>
                </div>

              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php require_once 'footer.php'; ?>